// Manifest V3 service worker.
// Opens side panel + navigates active tab to /showcases when the user clicks the extension action icon.
//
// Notes:
// - Some Chrome builds are flaky with openPanelOnActionClick, so we also handle action clicks explicitly.
// - We avoid requiring the "tabs" permission: onClicked may pass `tab` as undefined, so we open by windowId.

async function setOpenOnClickBehavior() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (_e) {
    // Side panel API may be unavailable in older Chrome versions.
  }
}

async function openSidePanelFromAction(tab) {
  try {
    if (!chrome.sidePanel || !chrome.sidePanel.open) return;

    await setOpenOnClickBehavior();

    const winId = tab && typeof tab.windowId === 'number'
      ? tab.windowId
      : (await chrome.windows.getCurrent()).id;
    if (typeof winId !== 'number') return;

    await chrome.sidePanel.open({ windowId: winId });

    // Open /showcases in a new tab so user sees product examples
    try {
      const { showcasesUrl } = await chrome.storage.local.get('showcasesUrl');
      if (showcasesUrl) {
        chrome.tabs.create({ url: showcasesUrl, active: true });
      }
    } catch (_navErr) {}
  } catch (_e) {}
}

chrome.runtime.onInstalled.addListener(() => void setOpenOnClickBehavior());
chrome.runtime.onStartup.addListener(() => void setOpenOnClickBehavior());
chrome.action.onClicked.addListener((tab) => void openSidePanelFromAction(tab));

// Listen for showcases URL from panel (set once on iframe load based on webchat origin)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'set_showcases_url' && message.url) {
    chrome.storage.local.set({ showcasesUrl: message.url });
  }
});

// Auto-open preview when index.html is created
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'open_preview' && message.url) {
    chrome.tabs.create({ url: message.url, active: true });
  }
});
