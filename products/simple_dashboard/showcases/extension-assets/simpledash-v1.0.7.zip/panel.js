// Panel script for WebChat sidebar with tab interaction capabilities.
// Provides: current tab info, page content reading, screenshot capture, developer mode element selection.
// UI controls (dev mode, showcases) live in webchat's hamburger menu — not in panel.html.

(function() {
  'use strict';

  const shared = (typeof window !== 'undefined' && window.WebchatSidebarShared)
    ? window.WebchatSidebarShared
    : null;
  const localEscapeHtml = (value) => String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

  const iframe = document.querySelector('iframe');
  if (!iframe) return;

  // Pass language to webchat: use navigator.language from extension page context
  // (navigator.language inside iframe may differ from the extension page)
  try {
    const nav = (navigator.language || '').toLowerCase();
    const langCode = nav.startsWith('ru') ? 'ru' : 'en';
    const iframeUrl = new URL(iframe.src);
    // Force HTTPS protocol (prevent CSP errors with HTTP)
    if (iframeUrl.protocol === 'http:' && iframeUrl.hostname !== 'localhost') {
      iframeUrl.protocol = 'https:';
    }
    if (!iframeUrl.searchParams.has('lang')) {
      iframeUrl.searchParams.set('lang', langCode);
    }
    iframe.src = iframeUrl.toString();
  } catch (_e) {}

  const iframeOrigin = new URL(iframe.src).origin;
  const capabilities = ['tab_info', 'read_page', 'screenshot', 'developer_mode', 'element_selection'];

  let developerModeEnabled = false;
  let bridgeInitialized = false;

  iframe.addEventListener('load', initCommunication);
  chrome.runtime.onMessage.addListener(handleRuntimeMessage);

  function initCommunication() {
    if (bridgeInitialized) return;
    bridgeInitialized = true;

    window.addEventListener('message', (event) => void handleMessage(event));
    sendToWebchat({ type: 'extension_ready', capabilities });
    sendDeveloperModeChanged();
  }

  async function handleMessage(event) {
    if (event.origin !== iframeOrigin) return;

    const message = event.data || {};
    const { type, requestId } = message;

    try {
      switch (type) {
        case 'get_tab_info':
          await handleGetTabInfo(requestId);
          break;
        case 'read_page_content':
          await handleReadPageContent(requestId);
          break;
        case 'capture_screenshot':
          await handleCaptureScreenshot(requestId);
          break;
        case 'set_developer_mode': {
          const enabled = readEnabledFlag(message);
          await setDeveloperMode(enabled);
          sendResponse(requestId, { enabled: developerModeEnabled });
          break;
        }
        case 'get_developer_mode_state':
          sendResponse(requestId, { enabled: developerModeEnabled });
          break;
        case 'clear_selected_element':
          await clearSelectionInActiveTab();
          sendResponse(requestId, { cleared: true });
          break;
        case 'file_created':
          handleFileCreated(message);
          break;
        case 'open_showcases':
          // Webchat requests to open /showcases in main browser tab
          try {
            chrome.tabs.create({ url: iframeOrigin + '/showcases', active: true });
          } catch (_e) {}
          break;
      }
    } catch (error) {
      sendToWebchat({
        type: 'response',
        requestId,
        error: error && error.message ? error.message : 'Unknown error'
      });
    }
  }

  function handleFileCreated(message) {
    const action = shared && typeof shared.toOpenPreviewAction === 'function'
      ? shared.toOpenPreviewAction(message)
      : null;
    if (!action) return;
    chrome.runtime.sendMessage(action);
  }

  async function handleGetTabInfo(requestId) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      throw new Error('No active tab found');
    }

    sendResponse(requestId, {
      title: tab.title,
      url: tab.url,
      favIconUrl: tab.favIconUrl,
      id: tab.id
    });
  }

  async function handleReadPageContent(requestId) {
    const tab = await getActiveTabOrThrow();
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageContent
    });

    if (!results || !results[0]) {
      throw new Error('Failed to extract page content');
    }

    sendResponse(requestId, {
      title: tab.title,
      url: tab.url,
      content: results[0].result
    });
  }

  async function handleCaptureScreenshot(requestId) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) {
      throw new Error('No active tab found');
    }

    const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
    sendResponse(requestId, {
      title: tab.title,
      url: tab.url,
      screenshot: dataUrl
    });
  }

  function handleRuntimeMessage(message) {
    if (!message || typeof message !== 'object') return;

    if (message.type === 'dev_mode_element_selected') {
      const data = normalizeElementPayload(message.payload);
      sendToWebchat({
        type: 'dev_element_selected',
        data: {
          ...data,
          chatText: formatElementForChat(data)
        }
      });
    } else if (message.type === 'dev_mode_selection_cleared') {
      sendToWebchat({ type: 'dev_element_selection_cleared' });
    }
  }

  async function setDeveloperMode(enabled) {
    const nextState = Boolean(enabled);
    const tab = await getActiveTabOrThrow();

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: setElementPickerMode,
      args: [nextState]
    });

    developerModeEnabled = nextState;
    sendDeveloperModeChanged(tab.id);
  }

  async function clearSelectionInActiveTab() {
    const tab = await getActiveTabOrThrow();

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: clearElementPickerSelection
    });

    sendDeveloperModeChanged(tab.id);
  }

  async function getActiveTabOrThrow() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      throw new Error('No active tab found');
    }
    return tab;
  }

  function sendResponse(requestId, data) {
    sendToWebchat({
      type: 'response',
      requestId,
      data
    });
  }

  function sendDeveloperModeChanged(tabId) {
    sendToWebchat({
      type: 'developer_mode_changed',
      data: {
        enabled: developerModeEnabled,
        tabId: typeof tabId === 'number' ? tabId : null
      }
    });
  }

  function sendToWebchat(message) {
    if (!iframe.contentWindow) return;
    iframe.contentWindow.postMessage(message, iframeOrigin);
  }

  function readEnabledFlag(message) {
    if (typeof message.enabled === 'boolean') return message.enabled;
    if (message.data && typeof message.data.enabled === 'boolean') return message.data.enabled;
    throw new Error('`enabled` boolean is required');
  }

  function normalizeElementPayload(payload) {
    const safe = payload && typeof payload === 'object' ? payload : {};
    return {
      tag: String(safe.tag || '').toLowerCase() || 'unknown',
      id: String(safe.id || ''),
      classes: String(safe.classes || ''),
      selector: String(safe.selector || '')
    };
  }

  function formatElementForChat(element) {
    return [
      'Element selected:',
      `- Tag: ${element.tag || '(unknown)'}`,
      `- ID: ${element.id || '(none)'}`,
      `- Classes: ${element.classes || '(none)'}`,
      `- Selector: ${element.selector || '(unknown)'}`
    ].join('\n');
  }

  // This function runs in the context of the active tab.
  function extractPageContent() {
    const textContent = document.body.innerText || '';
    const htmlContent = document.documentElement.outerHTML;

    const meta = {
      description: document.querySelector('meta[name="description"]')?.content || '',
      keywords: document.querySelector('meta[name="keywords"]')?.content || '',
      ogTitle: document.querySelector('meta[property="og:title"]')?.content || '',
      ogDescription: document.querySelector('meta[property="og:description"]')?.content || ''
    };

    const headings = Array.from(document.querySelectorAll('h1, h2, h3'))
      .map((h) => ({ tag: h.tagName, text: h.innerText }))
      .slice(0, 20);

    const links = Array.from(document.querySelectorAll('a[href]'))
      .map((a) => ({ href: a.href, text: a.innerText }))
      .slice(0, 50);

    return {
      text: textContent.substring(0, 50000),
      html: htmlContent.substring(0, 100000),
      meta,
      headings,
      links
    };
  }

  // This function runs in the context of the active tab.
  function setElementPickerMode(enabled) {
    const KEY = '__webchatSidebarElementPicker__';
    const HIGHLIGHT_OUTLINE = '2px solid #22c55e';

    function escapeCssIdent(value) {
      if (window.CSS && typeof window.CSS.escape === 'function') {
        return window.CSS.escape(value);
      }
      return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
    }

    function restoreSelection(state) {
      if (!state || !state.selected) return;
      const { element, outline, outlineOffset } = state.selected;
      if (element && element.isConnected) {
        element.style.outline = outline;
        element.style.outlineOffset = outlineOffset;
      }
      state.selected = null;
    }

    function getClassNames(element) {
      if (!element) return '';
      if (typeof element.className === 'string') return element.className.trim();
      const classAttr = element.getAttribute && element.getAttribute('class');
      return classAttr ? String(classAttr).trim() : '';
    }

    function segmentFor(element) {
      const tag = element.tagName.toLowerCase();
      if (element.id) {
        return `${tag}#${escapeCssIdent(element.id)}`;
      }

      const classNames = Array.from(element.classList || []).filter(Boolean).slice(0, 2);
      if (classNames.length > 0) {
        return `${tag}${classNames.map((cls) => `.${escapeCssIdent(cls)}`).join('')}`;
      }

      const parent = element.parentElement;
      if (!parent) return tag;

      const sameTagSiblings = Array.from(parent.children).filter((child) => child.tagName === element.tagName);
      if (sameTagSiblings.length <= 1) return tag;

      const index = sameTagSiblings.indexOf(element) + 1;
      return `${tag}:nth-of-type(${index})`;
    }

    function buildSelector(element) {
      const segments = [];
      let current = element;
      let depth = 0;
      while (current && current.nodeType === Node.ELEMENT_NODE && depth < 10) {
        segments.unshift(segmentFor(current));
        if (current.id) break;
        current = current.parentElement;
        depth += 1;
      }
      return segments.join(' > ');
    }

    function sendSelectionPayload(element) {
      const payload = {
        tag: element.tagName.toLowerCase(),
        id: element.id || '',
        classes: getClassNames(element),
        selector: buildSelector(element)
      };
      try {
        chrome.runtime.sendMessage({ type: 'dev_mode_element_selected', payload });
      } catch (_e) {}
    }

    const existing = window[KEY];
    if (!enabled) {
      if (existing) {
        restoreSelection(existing);
        document.removeEventListener('click', existing.onClick, true);
        document.removeEventListener('keydown', existing.onKeyDown, true);
        delete window[KEY];
      }
      return { enabled: false };
    }

    if (existing && existing.enabled) {
      return { enabled: true };
    }

    const state = existing || { enabled: true, selected: null, onClick: null, onKeyDown: null };
    state.enabled = true;

    state.onClick = function(event) {
      if (!event || !event.target || !(event.target instanceof Element)) return;
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }

      const element = event.target;
      restoreSelection(state);

      state.selected = {
        element,
        outline: element.style.outline || '',
        outlineOffset: element.style.outlineOffset || ''
      };

      element.style.outline = HIGHLIGHT_OUTLINE;
      element.style.outlineOffset = '2px';
      sendSelectionPayload(element);
    };

    state.onKeyDown = function(event) {
      if (!event || event.key !== 'Escape') return;
      restoreSelection(state);
      try {
        chrome.runtime.sendMessage({ type: 'dev_mode_selection_cleared' });
      } catch (_e) {}
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
    };

    document.addEventListener('click', state.onClick, true);
    document.addEventListener('keydown', state.onKeyDown, true);

    window[KEY] = state;
    return { enabled: true };
  }

  // This function runs in the context of the active tab.
  function clearElementPickerSelection() {
    const KEY = '__webchatSidebarElementPicker__';
    const state = window[KEY];
    if (!state || !state.selected) return { cleared: false };

    const { element, outline, outlineOffset } = state.selected;
    if (element && element.isConnected) {
      element.style.outline = outline;
      element.style.outlineOffset = outlineOffset;
    }
    state.selected = null;

    try {
      chrome.runtime.sendMessage({ type: 'dev_mode_selection_cleared' });
    } catch (_e) {}

    return { cleared: true };
  }
})();
