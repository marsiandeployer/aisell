// Manifest V3 service worker.
// Opens side panel + new tab with /showcases on icon click.

const WEBCHAT_URL = 'https://simpledashboard.wpmix.net';

function getShowcasesUrl() {
  try {
    const origin = new URL(WEBCHAT_URL).origin;
    return origin + '/showcases';
  } catch (_e) {
    return '';
  }
}

async function setOpenOnClickBehavior() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (_e) {}
}

async function openSidePanelFromAction(tab) {
  try {
    if (!chrome.sidePanel || !chrome.sidePanel.open) return;

    await setOpenOnClickBehavior();

    const winId = tab && typeof tab.windowId === 'number'
      ? tab.windowId
      : (await chrome.windows.getCurrent()).id;
    if (typeof winId !== 'number') return;

    await chrome.sidePanel.open({ windowId: winId });

    // Open /showcases in a new tab
    const showcasesUrl = getShowcasesUrl();
    if (showcasesUrl) {
      chrome.tabs.create({ url: showcasesUrl, active: true });
    }
  } catch (_e) {}
}

chrome.runtime.onInstalled.addListener(() => void setOpenOnClickBehavior());
chrome.runtime.onStartup.addListener(() => void setOpenOnClickBehavior());
chrome.action.onClicked.addListener((tab) => void openSidePanelFromAction(tab));

// Auto-open preview when index.html is created
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'open_preview' && message.url) {
    chrome.tabs.create({ url: message.url, active: true });
  }
});
